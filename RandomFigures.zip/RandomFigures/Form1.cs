using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RandomFigures
{
    public partial class Form1 : Form
    {
        private class MyFigure
        {
            public string Type;
            public Rectangle Rect;
            public Point[] TrianglePoints;
            public Color Color;
        }

        private List<MyFigure> figures = new();
        private Random rand = new();

        // ����� � ������ �� ����� ������
        private CancellationTokenSource recCts, triCts, cirCts;
        private Task recTask, triTask, cirTask;

        public Form1()
        {
            InitializeComponent();
            btnStop.Text = "Stop";
        }

        private void btnRectangle_Click(object sender, EventArgs e)
        {
            if (recTask == null || recTask.IsCompleted)
            {
                recCts = new CancellationTokenSource();
                recTask = Task.Run(() => AddRectangleLoop(recCts.Token));
            }
        }

        private void btnTriangle_Click(object sender, EventArgs e)
        {
            if (triTask == null || triTask.IsCompleted)
            {
                triCts = new CancellationTokenSource();
                triTask = Task.Run(() => AddTriangleLoop(triCts.Token));
            }
        }

        private void btnCircle_Click(object sender, EventArgs e)
        {
            if (cirTask == null || cirTask.IsCompleted)
            {
                cirCts = new CancellationTokenSource();
                cirTask = Task.Run(() => AddCircleLoop(cirCts.Token));
            }
        }

        // Stop/Resume �����: �����/����� ������ ������������
        private bool paused = false;

        private void btnStop_Click(object sender, EventArgs e)
        {
            if (!paused) // Stop
            {
                recCts?.Cancel();
                triCts?.Cancel();
                cirCts?.Cancel();
                btnStop.Text = "Resume";
                paused = true;
            }
            else // Resume
            {
                // ������� ������ ������ ������� ����� (��� ���� ����, ����� �� ���� ������� ����� Stop)
                if (recTask == null || recTask.IsCompleted)
                {
                    recCts = new CancellationTokenSource();
                    recTask = Task.Run(() => AddRectangleLoop(recCts.Token));
                }
                if (triTask == null || triTask.IsCompleted)
                {
                    triCts = new CancellationTokenSource();
                    triTask = Task.Run(() => AddTriangleLoop(triCts.Token));
                }
                if (cirTask == null || cirTask.IsCompleted)
                {
                    cirCts = new CancellationTokenSource();
                    cirTask = Task.Run(() => AddCircleLoop(cirCts.Token));
                }
                btnStop.Text = "Stop";
                paused = false;
            }
        }

        private void btnClearAll_Click(object sender, EventArgs e)
        {
            figures.Clear();
            Invalidate();
        }

        private void AddRectangleLoop(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                this.Invoke(new Action(() => AddRectangle()));
                Thread.Sleep(1500);
            }
        }
        private void AddTriangleLoop(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                this.Invoke(new Action(() => AddTriangle()));
                Thread.Sleep(1500);
            }
        }
        private void AddCircleLoop(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                this.Invoke(new Action(() => AddCircle()));
                Thread.Sleep(1500);
            }
        }

        // ��������� �� ���������� �� ������ ������� �����������!
        private Color GetRandomColor()
        {
            return Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256));
        }

        private void AddRectangle()
        {
            int maxW = ClientSize.Width - 120;
            int maxH = ClientSize.Height;
            int w = rand.Next(30, Math.Max(31, maxW / 2));
            int h = rand.Next(30, Math.Max(31, maxH / 2));
            int x = rand.Next(0, Math.Max(1, maxW - w));
            int y = rand.Next(0, Math.Max(1, maxH - h));

            figures.Add(new MyFigure
            {
                Type = "rectangle",
                Rect = new Rectangle(x, y, w, h),
                Color = GetRandomColor()
            });
            Invalidate();
        }

        private void AddTriangle()
        {
            int maxW = ClientSize.Width - 120;
            int maxH = ClientSize.Height;
            Point p1 = new(rand.Next(0, Math.Max(1, maxW)), rand.Next(0, Math.Max(1, maxH)));
            Point p2 = new(rand.Next(0, Math.Max(1, maxW)), rand.Next(0, Math.Max(1, maxH)));
            Point p3 = new(rand.Next(0, Math.Max(1, maxW)), rand.Next(0, Math.Max(1, maxH)));
            figures.Add(new MyFigure
            {
                Type = "triangle",
                TrianglePoints = new[] { p1, p2, p3 },
                Color = GetRandomColor()
            });
            Invalidate();
        }

        private void AddCircle()
        {
            int maxW = ClientSize.Width - 120;
            int maxH = ClientSize.Height;
            int d = rand.Next(30, Math.Max(31, Math.Min(maxW, maxH) / 2));
            int x = rand.Next(0, Math.Max(1, maxW - d));
            int y = rand.Next(0, Math.Max(1, maxH - d));
            figures.Add(new MyFigure
            {
                Type = "circle",
                Rect = new Rectangle(x, y, d, d),
                Color = GetRandomColor()
            });
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            foreach (var fig in figures)
            {
                switch (fig.Type)
                {
                    case "rectangle":
                        e.Graphics.FillRectangle(new SolidBrush(fig.Color), fig.Rect);
                        break;
                    case "triangle":
                        if (fig.TrianglePoints != null)
                            e.Graphics.FillPolygon(new SolidBrush(fig.Color), fig.TrianglePoints);
                        break;
                    case "circle":
                        e.Graphics.FillEllipse(new SolidBrush(fig.Color), fig.Rect);
                        break;
                }
            }
        }
    }
}